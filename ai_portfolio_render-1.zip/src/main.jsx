
import React from "react";
import {createRoot} from "react-dom/client";
import "./styles.css";
function App(){
return <main className="wrap">
<section className="hero">
<h1>Ian Chege</h1>
<p className="tag">AI Data Specialist • AI-Focused Software Engineer • Full‑Stack Developer</p>
<p>I design AI workflows, automation systems, networking solutions and modern web applications. Passionate about improving Large Language Models through high-quality data creation, prompt engineering and evaluation.</p>
<div className="buttons">
<a href="mailto:chegeian88@gmail.com">Contact Me</a>
<a href="https://github.com/Zerocode-sean">GitHub</a>
</div>
</section>
<section>
<h2>Featured Projects</h2>
<div className="card"><h3>AI ISP Billing Platform</h3><p>Python, FastAPI, React, MikroTik, FreeRADIUS, M-PESA integration.</p></div>
<div className="card"><h3>E-Learning Platform</h3><p>Authentication, course management and interactive learning.</p></div>
<div className="card"><h3>Book Review Platform</h3><p>Content management, ratings and discussions.</p></div>
</section>
<section><h2>Skills</h2><p>Python • JavaScript • React • FastAPI • Docker • SQL • REST APIs • Prompt Engineering • LLM Evaluation • Networking • Linux</p></section>
<footer>© 2026 Ian Chege</footer>
</main>}
createRoot(document.getElementById("root")).render(<App/>);
