# Deploy on Render
Build Command: npm install && npm run build
Publish Directory: dist